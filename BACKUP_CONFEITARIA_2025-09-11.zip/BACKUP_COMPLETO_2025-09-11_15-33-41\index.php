<?php
echo "Servidor PHP funcionando na raiz!";
?>

