-- =====================================================
-- BACKUP COMPLETO DO BANCO DE DADOS - CONFEITARIA
-- Data: 2025-01-XX
-- Versão: 1.0
-- =====================================================

-- Criar banco de dados
CREATE DATABASE IF NOT EXISTS confeitaria CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE confeitaria;

-- Estrutura da tabela products
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    category VARCHAR(100) NOT NULL DEFAULT 'Bolos',
    description TEXT,
    image TEXT,
    tags TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    sales INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados de exemplo (produtos atuais)
INSERT INTO products (name, price, stock, category, description, image, tags, status, sales) VALUES
('Bolo de Chocolate', 45.00, 15, 'Bolos', 'Delicioso bolo de chocolate com cobertura cremosa', 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&h=300&fit=crop', 'chocolate,bolo,doce', 'active', 12),
('Torta de Morango', 38.50, 8, 'Tortas', 'Torta fresca de morango com creme', 'https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=400&h=300&fit=crop', 'morango,torta,fruta', 'active', 8),
('Cupcake de Baunilha', 12.00, 25, 'Cupcakes', 'Cupcake fofinho de baunilha com glacê colorido', 'https://images.unsplash.com/photo-1572453800999-e8d2dde9c24b?w=400&h=300&fit=crop', 'baunilha,cupcake,docinho', 'active', 20),
('Brigadeiro Gourmet', 8.50, 30, 'Doces', 'Brigadeiro artesanal com granulado premium', 'https://images.unsplash.com/photo-1481391319762-47dff72954d9?w=400&h=300&fit=crop', 'brigadeiro,chocolate,doce', 'active', 35),
('Pudim de Leite', 22.00, 12, 'Sobremesas', 'Pudim tradicional de leite condensado', 'https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=400&h=300&fit=crop', 'pudim,leite,sobremesa', 'active', 15);

-- Verificar dados inseridos
SELECT * FROM products;

-- Estatísticas do banco
SELECT 
    COUNT(*) as total_produtos,
    SUM(sales) as total_vendas,
    SUM(price * sales) as receita_total,
    AVG(price) as preco_medio
FROM products;

