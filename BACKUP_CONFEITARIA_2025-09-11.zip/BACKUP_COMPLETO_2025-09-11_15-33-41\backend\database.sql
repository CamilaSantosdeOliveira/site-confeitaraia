-- Criar banco de dados
CREATE DATABASE IF NOT EXISTS confeitaria_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE confeitaria_db;

-- Tabela de produtos
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    image VARCHAR(500),
    category VARCHAR(100),
    rating DECIMAL(3,2) DEFAULT 0,
    reviews INT DEFAULT 0,
    featured BOOLEAN DEFAULT FALSE,
    stock INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de usuários
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    role ENUM('admin', 'user') DEFAULT 'user',
    token VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de pedidos
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(255) NOT NULL,
    customer_email VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(20),
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'confirmed', 'preparing', 'ready', 'delivered', 'cancelled') DEFAULT 'pending',
    payment_method VARCHAR(50),
    payment_status ENUM('pending', 'paid', 'failed') DEFAULT 'pending',
    delivery_address TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de itens do pedido
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Inserir dados de exemplo
INSERT INTO products (name, description, price, image, category, rating, reviews, featured) VALUES
('Bolo de Chocolate Belga', 'A união perfeita de cacau 70% e um recheio cremoso. Irresistível!', 95.00, 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250&q=80', 'bolos', 4.9, 127, 1),
('Cupcakes Red Velvet', 'Massa aveludada com cobertura de cream cheese. Delicadeza em cada mordida.', 12.00, 'https://images.unsplash.com/photo-1614707267537-b85aaf00c4b7?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250&q=80', 'cupcakes', 4.8, 89, 1),
('Pudim Caseiro', 'Cremoso pudim de leite condensado com calda de açúcar caramelizado.', 25.00, 'https://images.unsplash.com/photo-1488477181946-6428a0291777?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250&q=80', 'sobremesas', 4.9, 156, 1),
('Bolo de Morango', 'Bolo branco com recheio de morango fresco e chantilly.', 85.00, 'https://images.unsplash.com/photo-1565958011703-44f9829ba187?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250&q=80', 'bolos', 4.7, 98, 0),
('Torta de Limão', 'Torta refrescante com base de biscoito e creme de limão.', 45.00, 'https://images.unsplash.com/photo-1551024506-0bccd828d307?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250&q=80', 'tortas', 4.6, 73, 0),
('Brigadeiro Gourmet', 'Brigadeiro artesanal com chocolate belga e granulado premium.', 8.00, 'https://images.unsplash.com/photo-1488477181946-6428a0291777?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250&q=80', 'doces', 4.8, 234, 0);

-- Inserir usuário admin
INSERT INTO users (name, email, password, role) VALUES
('Administrador', 'admin@confeitaria.com', MD5('admin123'), 'admin'),
('João Silva', 'joao@email.com', MD5('123456'), 'user');

